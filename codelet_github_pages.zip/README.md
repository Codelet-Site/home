# Codelet - GitHub Pages Ready

This project is set up to deploy on GitHub Pages. It uses Firebase Authentication and Firestore. Replace the firebaseConfig in `auth.js` with your project's configuration (already included if you provided it).

Files:
- index.html
- signup.html
- login.html
- dashboard.html
- lessons.html
- projects.html
- settings.html
- style.css
- auth.js

To deploy: push to GitHub and enable GitHub Pages from the repo Settings -> Pages.
